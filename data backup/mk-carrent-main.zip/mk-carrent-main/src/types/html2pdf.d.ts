
declare module 'html2pdf.js';

    